		         /*-----About Online Voting System----*/
<html>
<head>
<title>about e-voting</title>
<?php include 'homex.php';?>
<style>
p.oblique {
    font-style: oblique;
}
body
{
background :url(x.jpg);
background-repeat:no repeat;

}
#topbar{
width:1400px;
margin:0 auto;
background-color:gainsboro;
height:130px;
}
#bar{
width:1400px;
margin:0 auto;
background-color:#607D8B;
height:260px;
}
</style>
</head>
<body>
<div id="topbar">
<div id="bar">
<p class="oblique"><p>The online voting system is the system that aims in reducing the complexity and cost of theelection process. </p>
<p>Here the voter can vote in spite of his absence in the particular locality. </p>
<p>The administrator effort is much reduced by checking the election status of all the localitiesindividually forms a place and it is easy for him to announce the election result.</p>
<p> The administrator is the soul controller of the online voting system in all process .</p>
<p>Thus the online voting system can reduce the cost and effort of election process.</p>
<p>In this voting system each voter will be provided with a specific voter-id and a passwordthrough which access for the voting can be granted.</p>
<p> If once the access is granted for a voter-idthen the access is denied for logging in till the voting system is refreshed for the next election.</p>
<p>Similarly the administrator will be provided with a special id through which he can view the status of the election.</p></div>
</body>
</html>