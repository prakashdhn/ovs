# OVS
OVS stands for Online Voting System. It's main aim is to eradicate the need of physical presence at the time of voting.
