
<html>
<head>
  <style>
#mainmenu ul li {
  display: inline;  
}

#mainmenu ul {
  margin: 0;
  padding: 0;
  
  list-style-type: none;
}

#mainmenu li {
  font-size: 1px;
  width: 1px;
  padding: 0;
}

#mainmenu span {
  height: 31px;

  padding: 0px;
  margin: 0px
  font-size: 1px;
}

</style>  
</head>
<body>
  <div id="pagebody">
    <br /><br />
    <div id="mainmenu">
      <ul>
        <li><a href="#" title="Home"><span id="menuitem_1" />1</span></a></li>
        <li><a href="#" title="Services"><span id="menuitem_2">2</span></a></li>
        <li><a href="#" title="Portfolio"><span id="menuitem_3">3</span></a></li>
        <li><a href="#" title="Resources"><span id="menuitem_4">4</span></a></li>
        <li><a href="#" title="Company"><span id="menuitem_5">5</span></a></li>
        <li><a href="#" title="Contact"><span id="menuitem_6">6</span></a></li>
      </ul>
    </div>
  </div>
</body>
</html>


