				/*-----Admin_Function----*/
<!DOCTYPE html>
<html>
<head>
<style>

body{background :url(admin.png);
}
input[type=submit] {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 16px 32px;

    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
position:relative;
left:140px;
bottom:40px;
}
</style>
</head>
<body>

<p style="margin-bottom:20px"></p>
<form action='register.php'>
<center><b>ADD VOTERS</b><br><input type="submit" value="submit"><center/>
</form>
<form action='delete.php'>
<center><b>DELETE VOTERS</b><br><input type="submit" value="submit"></center>


</div  style="float:right;">
<form action='admin.php'>
<center><b>LOGOUT</b><br><input type="submit" value="submit"></center>
</form>
</div>



</body>
</html>

