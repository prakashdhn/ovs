<html>
<head>
<style type="text/css">
body{
padding:0;
}
#topbar
{
width: 97%; top:0;
background-color:grey;
height:100px;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
font_size:100px;
}
li {
    width: 190px;
    float: left;
    border-right:1px solid #bbb;
	font_size:20%;
	}



li a {
    display: block;
    color: pink;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
	font_size:20%;
}

body
{
background-repeat:no repeat;

}


h1{

text-align: center;
font_size:100px;

}
</style>
</head>
<body>
<div id="topbar">
<p> <h1 style="color:black;"> ONLINE VOTING SYSTEM </h1></P>
<ul>
  <li><a href="home.php">HOME</a></li>
  <li><a href="#about">ABOUT i-VOTING</a></li>
  <li><a href="login1.php">LOGIN</a></li>
  <li><a href="result.php">RESULT</a></li>
  <li><a href="contact.php">CONTACT</a></li>
  <li style=" float:right;"><a href="admin.php">ADMIN</a></li>
</ul>
</div>

</body>
</html>

