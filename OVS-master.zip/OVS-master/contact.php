				/*-----Contact_Us-----*/
<html>
<head>
<?php include 'homex.php';?>
<style type="text/css">
body
{
background-repeat:no repeat;
background-size:100%;
}

</style>
<body>

<div style="background-color:#1abc9c;color:white;padding:20px;">
</div>
<div style="background-color:#2f4f4f;color:white;padding:20px;">

<address>
For any Queries you may Contact to:-.<br>
<br>
<br>

NAFISH AFTAB:<br>
email:  nafsaftab@gmail.com<br>
Mob:7736125611<br>
<br>

PRAKASH RANJAN:<br>
e-mail:  prakash_ranjan@gmail.com<br>
Mob:7736268149<br>

</address>
</div>

<div style="background-color:#1abc9c;color:white;padding:20px;height:50%;">
</div>

</body>
</html>
